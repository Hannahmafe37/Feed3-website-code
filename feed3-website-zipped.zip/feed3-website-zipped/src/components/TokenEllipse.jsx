import React from 'react'
function TokenEllipse() {
  return (
    <div className='token-ellipse'>
        <div className='web-ellipse'>
            {/* <img src={star} alt='' className='star'/> */}
            <div className="ellipse-timer">
            </div>
            <div className="ellipse-left">
            </div>
            <div className="ellipse-right">
            </div>
            <div className="ellipse-token">
            </div>
            <div className="ellipse-client">
            </div>
        </div>
        <div className='mobile-ellipse'>
            <div className="ellipse-head">
            </div>
            <div className="ellipse-utility">
            </div>
            <div className="ellipse-feedback">
            </div>
          
        </div>
    </div>
  )
}

export default TokenEllipse