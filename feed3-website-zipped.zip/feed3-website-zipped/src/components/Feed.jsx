import React from 'react'
function Feed() {
  return (
    <div className='feed'>
        {/* <img src={feed} alt='feed' width='95%'/> */}
    </div>
  )
}

export default Feed